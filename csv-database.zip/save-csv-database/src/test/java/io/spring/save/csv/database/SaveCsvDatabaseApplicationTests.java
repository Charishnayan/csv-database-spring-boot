package io.spring.save.csv.database;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaveCsvDatabaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
