package io.spring.save.csv.database.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import io.spring.save.csv.database.entity.Tutorial;

public interface TutorialRepository extends JpaRepository<Tutorial, Long>{

}
