package io.spring.save.csv.database.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.spring.save.csv.database.service.TutorialService;

@RestController
@RequestMapping("/api/csv")
public class TutorialController {

    private final TutorialService tutorialService;

//    @Value("${csv.file.path}") // This uses Spring's property injection
    private String csvFilePath = "C:\\Users\\ankit.kumarsingh\\Desktop\\details.csv";

    @Autowired
    public TutorialController(TutorialService tutorialService) {
        this.tutorialService = tutorialService;
    }

    @PostMapping("/import")
    public String importCsvData() {
        try {
            tutorialService.saveCSVDataToDatabase(csvFilePath);
            return "CSV data imported successfully.";
        } catch (IOException e) {
            return "Error importing CSV data: " + e.getMessage();
        }
    }
}
