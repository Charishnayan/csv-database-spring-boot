package io.spring.save.csv.database.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ResourceUtils;
import io.spring.save.csv.database.entity.Tutorial;
import io.spring.save.csv.database.repository.TutorialRepository;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

@Service
public class TutorialService {

    private final TutorialRepository tutorialRepository;

    @Autowired
    public TutorialService(TutorialRepository tutorialRepository) {
        this.tutorialRepository = tutorialRepository;
    }

    @Transactional
    public void saveCSVDataToDatabase(String csvFilePath) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(ResourceUtils.getFile(csvFilePath)));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] data = line.split(",");
            Tutorial tutorial = new Tutorial();
            tutorial.setTitle(data[1]);
            tutorial.setDescription(data[2]);
            tutorial.setPublished(Boolean.parseBoolean(data[3]));
            tutorialRepository.save(tutorial);
        }
    }
}




